@extends('components.head')

  <body id="home">

@extends('components.navbar')

    {{ $slot }}

@extends('components.footer')

  </body>
</html>
