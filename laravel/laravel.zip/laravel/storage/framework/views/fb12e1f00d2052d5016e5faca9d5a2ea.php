<?php 

error_reporting(E_ALL);
ini_set('display_errors', 1);

?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Sayid's Portofolio</title>

    <!-- bootstrap 5 css -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous" />

    <!-- Font -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Edu+VIC+WA+NT+Beginner:wght@400..700&display=swap" rel="stylesheet">

    <!-- icons -->
    <link rel="icon" type="icon/x-icon" href="https://icons8.com/icon/83326/home" />

    <!-- My CSS -->
    <link rel="stylesheet" type="text/css" href="/css/style.css">

  </head><?php /**PATH /Users/admin/Documents/Web Development/Projects/Portofolio 2/Portofolio/resources/views/template/head.blade.php ENDPATH**/ ?>