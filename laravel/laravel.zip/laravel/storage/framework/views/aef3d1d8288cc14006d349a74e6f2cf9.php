<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

<section>

    <!-- body -->
    <section id="about" class="section-hidden">
      <div class="container">
        <div class="row text-center mb-3 mt-5">
          <div class="col fw-light">
            <h2 class="font-judul"><?php echo e($project->judul); ?></h2>
          </div>
        </div>
        <div class="row text-center fs-5 justify-content-around mb-5">
          <div class="col-md-10 fw-light">
              <p class="fs-6 fs-md-5 fs-lg-4">Lorem ipsum dolor sit amet consectetur adipisicing elit. Quidem expedita quos a impedit libero dolorum architecto praesentium odit rerum id vel earum, ipsum asperiores delectus animi omnis debitis. Assumenda accusamus doloribus magnam excepturi. Optio ullam reprehenderit aliquid id temporibus dicta laudantium molestias nostrum deserunt culpa sint, ea magni qui atque, velit esse, praesentium cupiditate veniam porro. Illo, dolore non dolorem praesentium doloribus a, magni minima velit fugiat facere hic, suscipit quidem odio perspiciatis accusantium repudiandae accusamus dolor cupiditate harum eveniet id atque necessitatibus recusandae. Quas placeat consectetur quae voluptatum voluptatibus necessitatibus officia amet nihil nesciunt, vitae ab veniam ipsa laudantium.</p>
          </div>
        </div>
        <div class="row text-center fs-5 justify-content-around mb-5">
          <div class="col-md-10 fw-light">
              <p>webdev</p>
          </div>
        </div>
      </div>
    </section>
    <!-- Akhir body -->


</section>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?><?php /**PATH /Users/admin/Documents/Web Development/Projects/Portofolio 2/Portofolio/resources/views/web%20development.blade.php ENDPATH**/ ?>